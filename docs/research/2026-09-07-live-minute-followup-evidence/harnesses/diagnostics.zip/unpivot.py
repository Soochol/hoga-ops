import json,time,statistics,re
from pathlib import Path
from unittest.mock import patch
from hoga.api.queries import QueryEngine
from hoga.api.invariants import normalize_session_bounds,indicator_session_bounds
from hoga.tables import snapshots as s
root=Path('/home/dev/.local/share/hoga-ops/data');out=[]
class Unpivot:
 def __init__(self,con,kind,bucket):self.con=con;self.kind=kind;self.bucket=bucket
 def execute(self,sql,params=None):
  if self.kind=='peak' and "SELECT 'ask' AS side, 'cont' AS source" in sql:
   intra=s.hhmmssms_to_intra_ms_sql('ts_ms');pieces=[]
   for source in ['cont','rep']:
    for side,p,q in [('ask','ask_p','ask_q'),('bid','bid_p','bid_q')]:
     ps=','.join(p+str(i) for i in range(1,11));qs=','.join(q+str(i) for i in range(1,11))
     pieces.append(f"SELECT side, source, ts_ms, seq, price, qty, intra_ms, bucket_id, minute_id FROM (SELECT '{side}' AS side, '{source}' AS source, ts_ms, seq, unnest([{ps}]) AS price, unnest([{qs}]) AS qty, {intra} AS intra_ms, bucket_id, minute_id FROM {source}) WHERE qty > 0")
   pos=sql.index("SELECT 'ask' AS side, 'cont' AS source");sql=sql[:pos]+' UNION ALL '.join(pieces)
  elif self.kind=='depth' and 'levels AS (' in sql:
   pieces=[]
   for side,p,q in [('ask','ask_p','ask_q'),('bid','bid_p','bid_q')]:
    ps=','.join(p+str(i) for i in range(1,11));qs=','.join(q+str(i) for i in range(1,11))
    pieces.append(f"SELECT bucket, side, price, qty FROM (SELECT bucket, '{side}' AS side, unnest([{ps}]) AS price, unnest([{qs}]) AS qty FROM keyed) WHERE price>0 AND qty>0")
   a=sql.index('levels AS (')+len('levels AS (');z=sql.index('),\n        per_price AS',a);sql=sql[:a]+' UNION ALL '.join(pieces)+sql[z:]
  return self.con.execute(sql,params) if params is not None else self.con.execute(sql)
for date,code in [('20260904','005930'),('20260623','000660'),('20260904','287840')]:
 engine=QueryEngine(root);p=engine.parquet_dir(date,code,'hogaplay',venue='KRX');meta,_=normalize_session_bounds(json.loads((p/'meta.json').read_text()));op,cl=indicator_session_bounds(meta)
 for kind in ['peak','depth']:
  for bucket in [60000,300000]:
   base=dict(path=p/'snapshots.parquet',bucket_ms=bucket,session_open_ms=op,session_close_ms=cl)
   if kind=='peak':fn=s.query_day_ask_bid_peak_dual_with_rep;base['trades_path']=p/'trades.parquet'
   else:fn=s.query_bucketed_depth_heatmap
   a=[];z=[];equal=True
   for i in range(3):
    for variant in (['original','candidate'] if i%2==0 else ['candidate','original']):
     t=time.perf_counter();v=fn(engine.conn if variant=='original' else Unpivot(engine.conn,kind,bucket),**base);ms=(time.perf_counter()-t)*1000
     if variant=='original':ref=v;a.append(ms)
     else:candidate=v;z.append(ms)
    equal=equal and (ref==candidate)
   details=({'ask_equal':ref[0]==candidate[0],'bid_equal':ref[1]==candidate[1],'rep_rows_equal_as_set':sorted(map(repr,ref[2]))==sorted(map(repr,candidate[2]))} if kind=='peak' else {})
   row={'details':details,'code':code,'date':date,'kind':kind,'bucket':bucket,'baseline_ms':round(statistics.median(a),2),'candidate_ms':round(statistics.median(z),2),'equal':equal,'n':3};out.append(row);print(json.dumps(row),flush=True)
   # Record mismatch instead of accepting a speed-only candidate.
 engine.close()
Path('/tmp/minute-followup-5056-unpivot.json').write_text(json.dumps(out,indent=2))
