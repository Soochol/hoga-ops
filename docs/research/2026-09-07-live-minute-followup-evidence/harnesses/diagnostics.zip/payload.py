import json,time,urllib.parse
from pathlib import Path
import httpx
base=dict(code='005930',**{'from':'20260831','to':'20260904'},bucket_ms=60000,source_pref='hogaplay',venue='KRX',mode='sidecar',ask_peaks_enabled='true',bid_peaks_enabled='true',depth_heatmap_enabled='true',trade_volume_poc_enabled='true',program_trade_enabled='true',broker_late_entries_enabled='true',broker_late_entry_start_hhmm=900,volume_distribution_bins=15,trade_volume_poc_bins=15)
out=[]
with httpx.Client(base_url='http://localhost:8000',timeout=30) as client:
 for mode in ['sidecar','hoga']:
  for i in range(3):
   params={**base,'mode':mode};t=time.perf_counter()
   with client.stream('GET','/api/range',params=params) as response:
    head=time.perf_counter();data=response.read();done=time.perf_counter();x=json.loads(data);parsed=time.perf_counter()
   row={'mode':mode,'run':i,'status':response.status_code,'headers_ms':round((head-t)*1000,2),'body_ms':round((done-head)*1000,2),'json_ms':round((parsed-done)*1000,2),'bytes':len(data),'encoding':response.headers.get('content-encoding'),'field_bytes':{k:len(json.dumps(v,separators=(',',':')).encode()) for k,v in x.items() if isinstance(v,(dict,list))}};out.append(row);print(json.dumps(row),flush=True)
Path('/tmp/minute-followup-5056-payload.json').write_text(json.dumps(out,indent=2))
