import asyncio,json,time,tempfile,datetime,contextvars
from pathlib import Path
from unittest.mock import patch
import httpx
from hoga.live.kiwoom_rest import KiwoomRestClient
from hoga.live.kiwoom_capacity import KiwoomCapacityScheduler
from hoga.live.live_candle_backfill import LiveMinuteCandleBackfill
from hoga.live.past_candles_cache import PastCandlesCache
from hoga.live import kiwoom_rest_runtime
from hoga.api import calendar as trading_calendar
ctx=contextvars.ContextVar('trace',default=None)
rows=[]
class FrozenToken:
 def __init__(self):self.token=json.loads(Path('/home/dev/.local/share/hoga-ops/data/.local/kiwoom-token-5.json').read_text())['access_token']
 def get_token(self):return self.token
 # No credential loading, token issuance, invalidation, or token-file writes.
class Transport(httpx.AsyncBaseTransport):
 def __init__(self,expiry):self.inner=httpx.AsyncHTTPTransport(retries=1,limits=httpx.Limits(keepalive_expiry=expiry))
 async def handle_async_request(self,request):
  row=ctx.get();t=time.perf_counter();row['events']=[]
  async def trace(name,info):row['events'].append({'event':name,'ms':round((time.perf_counter()-t)*1000,2)})
  request.extensions['trace']=trace
  return await self.inner.handle_async_request(request)
 async def aclose(self):await self.inner.aclose()
class Client(KiwoomRestClient):
 async def call(self,api_id,body,**kw):
  t=time.perf_counter();row={'api':api_id,'base_dt':body.get('base_dt'),'upd':body.get('upd_stkpc_tp'),'start_ms':round((t-origin)*1000,2)};rows.append(row);token=ctx.set(row)
  try:
   result=await super().call(api_id,body,**kw);row['rows']=len(result.rows);return result
  except Exception as e:row['error']=type(e).__name__;raise
  finally:row['ms']=round((time.perf_counter()-t)*1000,2);ctx.reset(token)
class Scheduler(KiwoomCapacityScheduler):
 async def submit(self,*,key,api_id,priority,call):
  start=time.perf_counter()
  async def timed(client):
   enter=time.perf_counter();v=await call(client)
   if rows:rows[-1]['queue_and_pacing_ms']=round((enter-start)*1000,2)
   return v
  return await super().submit(key=key,api_id=api_id,priority=priority,call=timed)
origin=time.perf_counter();results=[]
async def main():
 token=FrozenToken()
 for expiry,codes in [(90,['005930','005380']),(0,['005930'])]:
  client=Client(token,transport=Transport(expiry));scheduler=Scheduler(rate_per_sec=1,workers=1)
  try:
   for code in codes:
    with tempfile.TemporaryDirectory(prefix='minute-followup-') as tmp:
     service=LiveMinuteCandleBackfill(data_dir=Path(tmp),cache=PastCandlesCache(Path(tmp)),scheduler=scheduler);stages=[]
     for name in ['_factors_or_failure','_walk_pending','_fetch_past_today_once']:
      fn=getattr(service,name)
      async def stage(*a,_fn=fn,_name=name,**kw):
       start=time.perf_counter()
       try:return await _fn(*a,**kw)
       finally:stages.append({'stage':_name,'ms':round((time.perf_counter()-start)*1000,2)})
      setattr(service,name,stage)
     with patch.object(kiwoom_rest_runtime,'ensure_rest_client',return_value=client),patch.object(trading_calendar,'is_trading_day',side_effect=lambda d:datetime.datetime.strptime(d,'%Y%m%d').weekday()<5):
      for phase in ['cold','warm']:
       rows.clear();stages.clear();start=time.perf_counter()
       response=await service.collect_minute(code=code,frm=datetime.date(2026,8,31),too=datetime.date(2026,9,7),today_d=datetime.date(2026,9,7),policy='KRX')
       result={'code':code,'expiry':expiry,'phase':phase,'total_ms':round((time.perf_counter()-start)*1000,2),'calls':list(rows),'stages':list(stages),'candles':len(response.candles),'fresh':response.fresh_dates,'warning_reasons':[w.get('reason') for w in response.data_warnings]};results.append(result)
       print(json.dumps(result),flush=True)
       if response.data_warnings:raise RuntimeError('Read-only probe stopped on warning')
  finally:await scheduler.aclose();await client.aclose()
Path('/tmp/minute-followup-5056-transport.json').write_text('[]')
try:asyncio.run(main())
finally:Path('/tmp/minute-followup-5056-transport.json').write_text(json.dumps(results,indent=2))
