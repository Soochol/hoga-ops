import json,time,tempfile,collections,statistics
from contextlib import ExitStack
from pathlib import Path
from unittest.mock import patch
from hoga.api.queries import QueryEngine
from hoga.api import bundle as b
from hoga.tables import snapshots as s
from tools.range_measurement_policy import fixture_only_trading_calendar
root=Path('/home/dev/.local/share/hoga-ops/data');results=[]
names=['_read_peak_wall_frames','_classify_wall_frame','_unreached_wall_frame','_unreached_bar_frame','_peak_rep_rows','_peak_record_sequence','_peak_bar_max_sequence','_peak_candidates','_peak_touched_distinct','query_bucketed_depth_heatmap']
for code,date in [('005930','20260904'),('000660','20260623'),('287840','20260904')]:
 for kind in ['peaks','depth']:
  with tempfile.TemporaryDirectory(prefix='minute-followup-compute-') as tmp:
   p=Path(tmp);(p/'parquet').symlink_to(root/'parquet',target_is_directory=True);engine=QueryEngine(p,temp_directory=p/'tmp');calls=collections.defaultdict(list)
   with ExitStack() as stack:
    stack.enter_context(fixture_only_trading_calendar())
    for name in names:
     fn=getattr(s,name)
     def wrapper(*a,_fn=fn,_name=name,**kw):
      t=time.perf_counter()
      try:return _fn(*a,**kw)
      finally:calls[_name].append((time.perf_counter()-t)*1000)
     stack.enter_context(patch.object(s,name,wrapper))
    base=dict(code=code,from_date=date,to_date=date,bucket_ms=60000,source_pref='hogaplay',venue='KRX',mode='sidecar',ask_peaks_enabled=kind=='peaks',bid_peaks_enabled=kind=='peaks',depth_heatmap_enabled=kind=='depth',trade_volume_poc_enabled=False,program_trade_enabled=False,broker_late_entries_enabled=False)
    for phase in ['cold','warm']:
     calls.clear();t=time.perf_counter();v=b.build_range_bundle(engine,**base);elapsed=(time.perf_counter()-t)*1000
     row=dict(code=code,date=date,kind=kind,phase=phase,total_ms=round(elapsed,2),functions={k:dict(ms=round(sum(a),2),calls=len(a)) for k,a in calls.items()});results.append(row);print(json.dumps(row),flush=True)
   engine.close()
Path('/tmp/minute-followup-5056-compute.json').write_text(json.dumps(results,indent=2))
