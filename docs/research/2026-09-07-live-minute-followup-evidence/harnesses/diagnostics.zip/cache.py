import json,time,tempfile
from pathlib import Path
from hoga.api.queries import QueryEngine
from hoga.api.bundle import build_range_bundle
from tools.range_measurement_policy import fixture_only_trading_calendar
root=Path('/home/dev/.local/share/hoga-ops/data');out=[]
for kind in ['peaks','depth']:
 with tempfile.TemporaryDirectory(prefix='minute-followup-cache-') as tmp,fixture_only_trading_calendar():
  p=Path(tmp);(p/'parquet').symlink_to(root/'parquet',target_is_directory=True)
  args=dict(code='005930',from_date='20260831',to_date='20260904',bucket_ms=60000,source_pref='hogaplay',venue='KRX',mode='sidecar',ask_peaks_enabled=kind=='peaks',bid_peaks_enabled=kind=='peaks',depth_heatmap_enabled=kind=='depth',trade_volume_poc_enabled=False,program_trade_enabled=False,broker_late_entries_enabled=False)
  engine=QueryEngine(p,temp_directory=p/'tmp');ref=None
  for phase in ['cold','disk-warm-new-engine','memory-warm']:
   if phase=='disk-warm-new-engine':engine.close();engine=QueryEngine(p,temp_directory=p/'tmp')
   t=time.perf_counter();v=build_range_bundle(engine,**args).model_dump(mode='json');ms=(time.perf_counter()-t)*1000
   if ref is None:ref=v
   assert v==ref
   row={'kind':kind,'phase':phase,'ms':round(ms,2),'equal':True};out.append(row);print(json.dumps(row),flush=True)
  engine.close()
Path('/tmp/minute-followup-5056-cache.json').write_text(json.dumps(out,indent=2))
