import json,asyncio,datetime,tempfile
from pathlib import Path
from unittest.mock import patch
from hoga.live import live_candle_backfill as m
from hoga.live.kiwoom_adjust_factors import AdjustFactors
from hoga.live.kiwoom_rest import Page
from hoga.live.candle_models import LiveCandle
from hoga.live.past_candles_cache import PastCandlesCache
class Scheduler:
 async def submit(self,*,key,api_id,priority,call):return await call(None)
class Client:
 def __init__(self):self.calls=[]
 async def call(self,api_id,body,**kwargs):
  self.calls.append({'api':api_id,'upd':body.get('upd_stkpc_tp')})
  return Page(rows=[{'dt':'20260907','cur_prc':'100'},{'dt':'20260904','cur_prc':'50' if body['upd_stkpc_tp']=='1' else '100'}],cont=False,next_key='',raw={})
async def main():
 out=[]
 for venue in ['KRX','NXT','UN']:
  for cached_today in [False,True]:
   responses=[]
   for variant in ['current','today-only-factor-shortcut']:
    with tempfile.TemporaryDirectory() as tmp:
     client=Client();cache=PastCandlesCache(Path(tmp));bars=[LiveCandle(t_ms=1788768000000,open=100,high=102,low=99,close=101,volume=10)]
     if cached_today:cache.store_today(venue,'005930',[b.model_dump() for b in bars])
     service=m.LiveMinuteCandleBackfill(data_dir=Path(tmp),cache=cache,scheduler=Scheduler())
     async def fetch(*a,**k):client.calls.append({'api':'ka10080','today':True});return bars
     if variant!='current':
      async def factors(*a,**k):return AdjustFactors(as_of='20260907',dates=('20260907',),values=(1.0,)),None,False
      service._factors_or_failure=factors
     with patch.object(m.kiwoom_rest_runtime,'ensure_rest_client',return_value=client),patch.object(m.kiwoom_minute_candles,'fetch_day',fetch),patch.object(m.trading_calendar,'is_trading_day',return_value=True):
      v=await service.collect_minute(code='005930',frm=datetime.date(2026,9,7),too=datetime.date(2026,9,7),today_d=datetime.date(2026,9,7),policy=venue)
     responses.append(v.model_dump());out.append({'venue':venue,'today_cached':cached_today,'variant':variant,'calls':client.calls,'candles':len(v.candles),'adjust_factors':v.adjust_factors})
   assert responses[0]==responses[1],(venue,responses)
   out[-1]['entire_response_equal']=True
 print(json.dumps(out,indent=2));Path('/tmp/minute-followup-5056-today.json').write_text(json.dumps(out,indent=2))
asyncio.run(main())
