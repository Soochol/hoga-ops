import json,tempfile,shutil
from pathlib import Path
from hoga.api.bundle import build_range_bundle
from hoga.api.queries import QueryEngine
from tools.range_measurement_policy import fixture_only_trading_calendar
root=Path('/home/dev/.local/share/hoga-ops/data');out=[]
with tempfile.TemporaryDirectory(prefix='minute-followup-edge-') as tmp,fixture_only_trading_calendar():
 p=Path(tmp);q=p/'parquet'/'20260907'/'005930';shutil.copytree(root/'parquet'/'20260907'/'005930',q)
 # No historical raw data copied: the range intentionally includes missing dates.
 engine=QueryEngine(p,temp_directory=p/'tmp')
 for venue in ['KRX','UN','NXT']:
  for frm in ['20260907','20260904']:
   for with_price in [False,True]:
    base=dict(code='005930',from_date=frm,to_date='20260907',bucket_ms=60000,source_pref='kiwoom_live',venue=venue,mode='sidecar',ask_peaks_enabled=True,bid_peaks_enabled=True,depth_heatmap_enabled=True,trade_volume_poc_enabled=True,program_trade_enabled=True,broker_late_entries_enabled=True,broker_late_entry_start_hhmm=900,volume_distribution_bins=10,trade_volume_poc_bins=10)
    if with_price:base.update(volume_distribution_price_min=264000,volume_distribution_price_max=268000)
    original=build_range_bundle(engine,**base).model_dump(mode='json')
    ind=build_range_bundle(engine,**{**base,'volume_distribution_bins':None,'trade_volume_poc_enabled':False}).model_dump(mode='json')
    dep=build_range_bundle(engine,**{**base,'ask_peaks_enabled':False,'bid_peaks_enabled':False,'depth_heatmap_enabled':False,'program_trade_enabled':False,'broker_late_entries_enabled':False}).model_dump(mode='json')
    merged={**ind,'volume_distributions':dep['volume_distributions'],'trade_volume_pocs':dep['trade_volume_pocs']}
    diff=[k for k,v in original.items() if v!=merged[k]]
    row={'venue':venue,'from':frm,'price_supplied':with_price,'different_fields':diff,'segments':len(original['segments']),'missing':len(original['missing_dates']),'depth_points':len(original['depth_heatmap'])};out.append(row);print(json.dumps(row),flush=True)
    assert not diff
 engine.close()
Path('/tmp/minute-followup-5056-split-edge.json').write_text(json.dumps(out,indent=2))
