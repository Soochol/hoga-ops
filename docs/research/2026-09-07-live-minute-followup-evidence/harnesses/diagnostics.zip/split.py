import json,time,tempfile,concurrent.futures
from pathlib import Path
from contextlib import ExitStack
from tools.range_measurement_policy import fixture_only_trading_calendar
from hoga.api.queries import QueryEngine
from hoga.api.bundle import build_range_bundle
root=Path('/home/dev/.local/share/hoga-ops/data');output=[]
base=dict(from_date='20260831',to_date='20260904',bucket_ms=60000,source_pref='hogaplay',venue='KRX',mode='sidecar',ask_peaks_enabled=True,bid_peaks_enabled=True,depth_heatmap_enabled=True,trade_volume_poc_enabled=True,program_trade_enabled=True,broker_late_entries_enabled=True,broker_late_entry_start_hhmm=900,volume_distribution_bins=15,trade_volume_poc_bins=15)
for code in ['005930','000660','287840']:
 values={}
 for mode in ['monolithic','split']:
  with tempfile.TemporaryDirectory(prefix='minute-followup-split-') as tmp,fixture_only_trading_calendar():
   p=Path(tmp);(p/'parquet').symlink_to(root/'parquet',target_is_directory=True);(p/'kis-program-trade').symlink_to(root/'kis-program-trade',target_is_directory=True);engine=QueryEngine(p,temp_directory=p/'tmp');engine.indicators_cache
   def build(args):
    start=time.perf_counter();data=build_range_bundle(engine,code=code,**args).model_dump(mode='json');return data,round((time.perf_counter()-start)*1000,2)
   if mode=='monolithic':
    data,ms=build(base);values['monolithic']=data;row={'code':code,'mode':mode,'build_ms':ms}
   else:
    independent={**base,'volume_distribution_bins':None,'trade_volume_poc_enabled':False}
    dependent={**base,'ask_peaks_enabled':False,'bid_peaks_enabled':False,'depth_heatmap_enabled':False,'program_trade_enabled':False,'broker_late_entries_enabled':False}
    start=time.perf_counter()
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
     future=pool.submit(build,independent)
     time.sleep(1.4) # Controlled candle availability delay, NOT real API latency.
     second=pool.submit(build,dependent)
     ind,ind_ms=future.result();dep,dep_ms=second.result()
    total=round((time.perf_counter()-start)*1000,2)
    merged={**ind,'volume_distributions':dep['volume_distributions'],'trade_volume_pocs':dep['trade_volume_pocs']}
    diff=[k for k,v in values['monolithic'].items() if v!=merged[k]]
    row={'code':code,'mode':mode,'independent_ms':ind_ms,'dependent_ms':dep_ms,'simulated_candle_wait_ms':1400,'finish_ms':total,'monolithic_projected_finish_ms':1400+output[-1]['build_ms'],'different_top_level_fields':diff,'original_keys':len(values['monolithic'])}
    assert not diff,diff
   output.append(row);print(json.dumps(row),flush=True);engine.close()
Path('/tmp/minute-followup-5056-split.json').write_text(json.dumps(output,indent=2))
